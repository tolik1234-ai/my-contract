# ERC20Mock
[Git Source](https://github.com/SolidityUniversity/smart-deployer/blob/85c11aeeaafc38269bb5a66ecafac729e84c7b17/src/ERC20Mock.sol)

**Inherits:**
ERC20


## Functions
### constructor


```solidity
constructor(address recipient) payable ERC20("MyToken", "MTK");
```

