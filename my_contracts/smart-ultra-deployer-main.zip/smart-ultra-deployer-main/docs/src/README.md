# Smart Deployer

Smart Deployer is a universal architecture for organizing and managing paid smart contract deployments.

This solution allows developers to:

- Create their own Smart Deployer (DeployManager.sol)
- Create & connect utility contracts using template
- Monetize the deployment of utility contracts

> The repository is currently under development.
We are building it as part of the Solidity University Bootcamp program.

👉 More details: [bootcamp.solidity.university](https://bootcamp.solidity.university)
